#ifndef DEBUG_PRINTF_H
#define DEBUG_PRINTF_H

void DebugPrintfInit(void);

#endif
