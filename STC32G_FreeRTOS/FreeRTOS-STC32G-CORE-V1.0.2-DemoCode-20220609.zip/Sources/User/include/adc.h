
#ifndef ADC_H
#define ADC_H

void vAdcInit( void );
uint16_t usAdcGetResult(uint8_t ucChannel);

#endif
