#ifndef __SONIC_H__
#define __SONIC_H__

#include "boot.h"

void sonic_send();
uchar sonic_measure();


#endif