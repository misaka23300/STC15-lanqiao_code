#ifndef __IIC_H__
#define __IIC_H__

#include "boot.h"

void DAC(uchar value);

#endif