#ifndef __ONEWIRE_H__
#define __ONEWIRE_H__

#include "boot.h"

float read_temperature();

#endif