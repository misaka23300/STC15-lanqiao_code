#ifndef __KEY_H__
#define __KEY_H__

#include "boot.h"

uchar key_scan();

#endif
